<?php
include_once('includes/header.inc.php');
include_once('includes/alternatif.inc.php');
include_once('includes/kriteria.inc.php');
include_once('includes/ranking.inc.php');

$altObj = new Alternatif($db);

$kriObj = new Kriteria($db);

$ranObj = new Ranking($db);
$stmt = $ranObj->readKhusus();
$stmty = $ranObj->readKhusus();
$count = $ranObj->countAll();
$stmtx1y = $ranObj->readBob();
$stmtx2y = $ranObj->readBob();
?>
<center>
<div class="container">
	<img width="150px" height="100px" src="assets/images/e-clean2.jpg">
	<h3>PT. E-CLEAN INDONESIA MANDIRI</h3>
	<p>Jl. Merdeka Blok A No. 17-18 Ciputat, Tangerang Selatan</p>
	<p>Telp.021-74631184 / Fax. 021-74631185</p>
</center>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12">
		<br/>
		<h3>Keputusan Kenaikan Gaji</h3>
		<hr>
		<br>
		<!-- TAMBAH TAHUN -->
		
			
		<?php for ($i=2020; $i<=2020; $i++): ?>
			<option value="<?= $i ?>"></option>
		</datalist>
			<h4>Tahun <?=$i?></h4>
			<table width="100%" class="table table-striped table-bordered">
			    <thead>
					<tr>
						<th>NIK</th>
						<th>Nama</th>
						<th>Jabatan</th>
						<th>Tanggal Masuk</th>
						<th>Nilai</th>
						<th>Hasil</th>
					</tr>
			    </thead>
			    <tbody>
					<?php $altObj->periode = $i; $rank = "1"; $alt1c = $altObj->readByRank1(); while ($row = $alt1c->fetch(PDO::FETCH_ASSOC)): ?>
				        <tr>
							<td><?=$row["nik"]?></td>
							<td><?=$row["nama"]?></td>
							<td><?=$row["jabatan"]?></td>
							<td><?=$row["tanggal_masuk"]?></td>
							<td><?=number_format($row["hasil_akhir"], 4, '.','.')?></td>
						<?php echo $rank<4?"<td style='background-color:lime;'>$rank</td>":"<td style='background-color:red;'>$rank</td>";?>
						<!--td class="success"><?=$rank++?></td-->
						<?php $rank ?>
				        </tr>
					<?php endwhile; ?>
			    </tbody>
		  </table>
		  <br>
	  <?php endfor; ?>
	  <b>Keterangan :</b>
	  <p>1 - 3 = Berhak Naik Gaji</p>
	  <p>4 s/d Seterusnya = Tidak Berhak</p>
	</div>
</div>
<div style="text-align: right;">
				<p>Bekasi, <?php echo date('d/m/Y') ?></p>
				<!-- <p>Hormat Saya,</p> -->
				<br><br><br><br><br>
				<p>Ivon Kurnia</p>
			</div>

<?php include_once('includes/footer.inc.php'); ?>
