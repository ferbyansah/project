-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2021 at 06:38 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `employees`
--

-- --------------------------------------------------------

--
-- Table structure for table `analisa_alternatif`
--

CREATE TABLE `analisa_alternatif` (
  `alternatif_pertama` varchar(4) NOT NULL,
  `nilai_analisa_alternatif` double NOT NULL,
  `hasil_analisa_alternatif` double NOT NULL,
  `alternatif_kedua` varchar(4) NOT NULL,
  `id_kriteria` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `analisa_alternatif`
--

INSERT INTO `analisa_alternatif` (`alternatif_pertama`, `nilai_analisa_alternatif`, `hasil_analisa_alternatif`, `alternatif_kedua`, `id_kriteria`) VALUES
('A001', 1, 0.5625, 'A001', 'C1'),
('A001', 1, 0.5625, 'A001', 'C2'),
('A001', 1, 0.5625, 'A001', 'C3'),
('A001', 1, 0.5625, 'A001', 'C4'),
('A001', 1, 0.5625, 'A001', 'C5'),
('A001', 9, 0.84375, 'A002', 'C1'),
('A001', 9, 0.84375, 'A002', 'C2'),
('A001', 9, 0.84375, 'A002', 'C3'),
('A001', 9, 0.84375, 'A002', 'C4'),
('A001', 9, 0.84375, 'A002', 'C5'),
('A001', 9, 0.46022727272727, 'A003', 'C1'),
('A001', 9, 0.46022727272727, 'A003', 'C2'),
('A001', 9, 0.46022727272727, 'A003', 'C3'),
('A001', 9, 0.46022727272727, 'A003', 'C4'),
('A001', 9, 0.46022727272727, 'A003', 'C5'),
('A001', 9, 0.31640625, 'A004', 'C1'),
('A001', 9, 0.31640625, 'A004', 'C2'),
('A001', 9, 0.31640625, 'A004', 'C3'),
('A001', 9, 0.31640625, 'A004', 'C4'),
('A001', 9, 0.31640625, 'A004', 'C5'),
('A001', 9, 0.24107142857143, 'A005', 'C1'),
('A001', 9, 0.24107142857143, 'A005', 'C2'),
('A001', 9, 0.24107142857143, 'A005', 'C3'),
('A001', 9, 0.24107142857143, 'A005', 'C4'),
('A001', 9, 0.24107142857143, 'A005', 'C5'),
('A001', 9, 0.19471153846154, 'A006', 'C1'),
('A001', 9, 0.19471153846154, 'A006', 'C2'),
('A001', 9, 0.19471153846154, 'A006', 'C3'),
('A001', 9, 0.19471153846154, 'A006', 'C4'),
('A001', 9, 0.19471153846154, 'A006', 'C5'),
('A001', 9, 0.1633064516129, 'A007', 'C1'),
('A001', 9, 0.1633064516129, 'A007', 'C2'),
('A001', 9, 0.1633064516129, 'A007', 'C3'),
('A001', 9, 0.1633064516129, 'A007', 'C4'),
('A001', 9, 0.1633064516129, 'A007', 'C5'),
('A001', 9, 0.140625, 'A008', 'C1'),
('A001', 9, 0.140625, 'A008', 'C2'),
('A001', 9, 0.140625, 'A008', 'C3'),
('A001', 9, 0.140625, 'A008', 'C4'),
('A001', 9, 0.140625, 'A008', 'C5'),
('A002', 0.11111111111111, 0.0625, 'A001', 'C1'),
('A002', 0.11111111111111, 0.0625, 'A001', 'C2'),
('A002', 0.11111111111111, 0.0625, 'A001', 'C3'),
('A002', 0.11111111111111, 0.0625, 'A001', 'C4'),
('A002', 0.11111111111111, 0.0625, 'A001', 'C5'),
('A002', 1, 0.09375, 'A002', 'C1'),
('A002', 1, 0.09375, 'A002', 'C2'),
('A002', 1, 0.09375, 'A002', 'C3'),
('A002', 1, 0.09375, 'A002', 'C4'),
('A002', 1, 0.09375, 'A002', 'C5'),
('A002', 9, 0.46022727272727, 'A003', 'C1'),
('A002', 9, 0.46022727272727, 'A003', 'C2'),
('A002', 9, 0.46022727272727, 'A003', 'C3'),
('A002', 9, 0.46022727272727, 'A003', 'C4'),
('A002', 9, 0.46022727272727, 'A003', 'C5'),
('A002', 9, 0.31640625, 'A004', 'C1'),
('A002', 9, 0.31640625, 'A004', 'C2'),
('A002', 9, 0.31640625, 'A004', 'C3'),
('A002', 9, 0.31640625, 'A004', 'C4'),
('A002', 9, 0.31640625, 'A004', 'C5'),
('A002', 9, 0.24107142857143, 'A005', 'C1'),
('A002', 9, 0.24107142857143, 'A005', 'C2'),
('A002', 9, 0.24107142857143, 'A005', 'C3'),
('A002', 9, 0.24107142857143, 'A005', 'C4'),
('A002', 9, 0.24107142857143, 'A005', 'C5'),
('A002', 9, 0.19471153846154, 'A006', 'C1'),
('A002', 9, 0.19471153846154, 'A006', 'C2'),
('A002', 9, 0.19471153846154, 'A006', 'C3'),
('A002', 9, 0.19471153846154, 'A006', 'C4'),
('A002', 9, 0.19471153846154, 'A006', 'C5'),
('A002', 9, 0.1633064516129, 'A007', 'C1'),
('A002', 9, 0.1633064516129, 'A007', 'C2'),
('A002', 9, 0.1633064516129, 'A007', 'C3'),
('A002', 9, 0.1633064516129, 'A007', 'C4'),
('A002', 9, 0.1633064516129, 'A007', 'C5'),
('A002', 9, 0.140625, 'A008', 'C1'),
('A002', 9, 0.140625, 'A008', 'C2'),
('A002', 9, 0.140625, 'A008', 'C3'),
('A002', 9, 0.140625, 'A008', 'C4'),
('A002', 9, 0.140625, 'A008', 'C5'),
('A003', 0.11111111111111, 0.0625, 'A001', 'C1'),
('A003', 0.11111111111111, 0.0625, 'A001', 'C2'),
('A003', 0.11111111111111, 0.0625, 'A001', 'C3'),
('A003', 0.11111111111111, 0.0625, 'A001', 'C4'),
('A003', 0.11111111111111, 0.0625, 'A001', 'C5'),
('A003', 0.11111111111111, 0.010416666666667, 'A002', 'C1'),
('A003', 0.11111111111111, 0.010416666666667, 'A002', 'C2'),
('A003', 0.11111111111111, 0.010416666666667, 'A002', 'C3'),
('A003', 0.11111111111111, 0.010416666666667, 'A002', 'C4'),
('A003', 0.11111111111111, 0.010416666666667, 'A002', 'C5'),
('A003', 1, 0.051136363636364, 'A003', 'C1'),
('A003', 1, 0.051136363636364, 'A003', 'C2'),
('A003', 1, 0.051136363636364, 'A003', 'C3'),
('A003', 1, 0.051136363636364, 'A003', 'C4'),
('A003', 1, 0.051136363636364, 'A003', 'C5'),
('A003', 9, 0.31640625, 'A004', 'C1'),
('A003', 9, 0.31640625, 'A004', 'C2'),
('A003', 9, 0.31640625, 'A004', 'C3'),
('A003', 9, 0.31640625, 'A004', 'C4'),
('A003', 9, 0.31640625, 'A004', 'C5'),
('A003', 9, 0.24107142857143, 'A005', 'C1'),
('A003', 9, 0.24107142857143, 'A005', 'C2'),
('A003', 9, 0.24107142857143, 'A005', 'C3'),
('A003', 9, 0.24107142857143, 'A005', 'C4'),
('A003', 9, 0.24107142857143, 'A005', 'C5'),
('A003', 9, 0.19471153846154, 'A006', 'C1'),
('A003', 9, 0.19471153846154, 'A006', 'C2'),
('A003', 9, 0.19471153846154, 'A006', 'C3'),
('A003', 9, 0.19471153846154, 'A006', 'C4'),
('A003', 9, 0.19471153846154, 'A006', 'C5'),
('A003', 9, 0.1633064516129, 'A007', 'C1'),
('A003', 9, 0.1633064516129, 'A007', 'C2'),
('A003', 9, 0.1633064516129, 'A007', 'C3'),
('A003', 9, 0.1633064516129, 'A007', 'C4'),
('A003', 9, 0.1633064516129, 'A007', 'C5'),
('A003', 9, 0.140625, 'A008', 'C1'),
('A003', 9, 0.140625, 'A008', 'C2'),
('A003', 9, 0.140625, 'A008', 'C3'),
('A003', 9, 0.140625, 'A008', 'C4'),
('A003', 9, 0.140625, 'A008', 'C5'),
('A004', 0.11111111111111, 0.0625, 'A001', 'C1'),
('A004', 0.11111111111111, 0.0625, 'A001', 'C2'),
('A004', 0.11111111111111, 0.0625, 'A001', 'C3'),
('A004', 0.11111111111111, 0.0625, 'A001', 'C4'),
('A004', 0.11111111111111, 0.0625, 'A001', 'C5'),
('A004', 0.11111111111111, 0.010416666666667, 'A002', 'C1'),
('A004', 0.11111111111111, 0.010416666666667, 'A002', 'C2'),
('A004', 0.11111111111111, 0.010416666666667, 'A002', 'C3'),
('A004', 0.11111111111111, 0.010416666666667, 'A002', 'C4'),
('A004', 0.11111111111111, 0.010416666666667, 'A002', 'C5'),
('A004', 0.11111111111111, 0.0056818181818181, 'A003', 'C1'),
('A004', 0.11111111111111, 0.0056818181818181, 'A003', 'C2'),
('A004', 0.11111111111111, 0.0056818181818181, 'A003', 'C3'),
('A004', 0.11111111111111, 0.0056818181818181, 'A003', 'C4'),
('A004', 0.11111111111111, 0.0056818181818181, 'A003', 'C5'),
('A004', 1, 0.03515625, 'A004', 'C1'),
('A004', 1, 0.03515625, 'A004', 'C2'),
('A004', 1, 0.03515625, 'A004', 'C3'),
('A004', 1, 0.03515625, 'A004', 'C4'),
('A004', 1, 0.03515625, 'A004', 'C5'),
('A004', 9, 0.24107142857143, 'A005', 'C1'),
('A004', 9, 0.24107142857143, 'A005', 'C2'),
('A004', 9, 0.24107142857143, 'A005', 'C3'),
('A004', 9, 0.24107142857143, 'A005', 'C4'),
('A004', 9, 0.24107142857143, 'A005', 'C5'),
('A004', 9, 0.19471153846154, 'A006', 'C1'),
('A004', 9, 0.19471153846154, 'A006', 'C2'),
('A004', 9, 0.19471153846154, 'A006', 'C3'),
('A004', 9, 0.19471153846154, 'A006', 'C4'),
('A004', 9, 0.19471153846154, 'A006', 'C5'),
('A004', 9, 0.1633064516129, 'A007', 'C1'),
('A004', 9, 0.1633064516129, 'A007', 'C2'),
('A004', 9, 0.1633064516129, 'A007', 'C3'),
('A004', 9, 0.1633064516129, 'A007', 'C4'),
('A004', 9, 0.1633064516129, 'A007', 'C5'),
('A004', 9, 0.140625, 'A008', 'C1'),
('A004', 9, 0.140625, 'A008', 'C2'),
('A004', 9, 0.140625, 'A008', 'C3'),
('A004', 9, 0.140625, 'A008', 'C4'),
('A004', 9, 0.140625, 'A008', 'C5'),
('A005', 0.11111111111111, 0.0625, 'A001', 'C1'),
('A005', 0.11111111111111, 0.0625, 'A001', 'C2'),
('A005', 0.11111111111111, 0.0625, 'A001', 'C3'),
('A005', 0.11111111111111, 0.0625, 'A001', 'C4'),
('A005', 0.11111111111111, 0.0625, 'A001', 'C5'),
('A005', 0.11111111111111, 0.010416666666667, 'A002', 'C1'),
('A005', 0.11111111111111, 0.010416666666667, 'A002', 'C2'),
('A005', 0.11111111111111, 0.010416666666667, 'A002', 'C3'),
('A005', 0.11111111111111, 0.010416666666667, 'A002', 'C4'),
('A005', 0.11111111111111, 0.010416666666667, 'A002', 'C5'),
('A005', 0.11111111111111, 0.0056818181818181, 'A003', 'C1'),
('A005', 0.11111111111111, 0.0056818181818181, 'A003', 'C2'),
('A005', 0.11111111111111, 0.0056818181818181, 'A003', 'C3'),
('A005', 0.11111111111111, 0.0056818181818181, 'A003', 'C4'),
('A005', 0.11111111111111, 0.0056818181818181, 'A003', 'C5'),
('A005', 0.11111111111111, 0.00390625, 'A004', 'C1'),
('A005', 0.11111111111111, 0.00390625, 'A004', 'C2'),
('A005', 0.11111111111111, 0.00390625, 'A004', 'C3'),
('A005', 0.11111111111111, 0.00390625, 'A004', 'C4'),
('A005', 0.11111111111111, 0.00390625, 'A004', 'C5'),
('A005', 1, 0.026785714285714, 'A005', 'C1'),
('A005', 1, 0.026785714285714, 'A005', 'C2'),
('A005', 1, 0.026785714285714, 'A005', 'C3'),
('A005', 1, 0.026785714285714, 'A005', 'C4'),
('A005', 1, 0.026785714285714, 'A005', 'C5'),
('A005', 9, 0.19471153846154, 'A006', 'C1'),
('A005', 9, 0.19471153846154, 'A006', 'C2'),
('A005', 9, 0.19471153846154, 'A006', 'C3'),
('A005', 9, 0.19471153846154, 'A006', 'C4'),
('A005', 9, 0.19471153846154, 'A006', 'C5'),
('A005', 9, 0.1633064516129, 'A007', 'C1'),
('A005', 9, 0.1633064516129, 'A007', 'C2'),
('A005', 9, 0.1633064516129, 'A007', 'C3'),
('A005', 9, 0.1633064516129, 'A007', 'C4'),
('A005', 9, 0.1633064516129, 'A007', 'C5'),
('A005', 9, 0.140625, 'A008', 'C1'),
('A005', 9, 0.140625, 'A008', 'C2'),
('A005', 9, 0.140625, 'A008', 'C3'),
('A005', 9, 0.140625, 'A008', 'C4'),
('A005', 9, 0.140625, 'A008', 'C5'),
('A006', 0.11111111111111, 0.0625, 'A001', 'C1'),
('A006', 0.11111111111111, 0.0625, 'A001', 'C2'),
('A006', 0.11111111111111, 0.0625, 'A001', 'C3'),
('A006', 0.11111111111111, 0.0625, 'A001', 'C4'),
('A006', 0.11111111111111, 0.0625, 'A001', 'C5'),
('A006', 0.11111111111111, 0.010416666666667, 'A002', 'C1'),
('A006', 0.11111111111111, 0.010416666666667, 'A002', 'C2'),
('A006', 0.11111111111111, 0.010416666666667, 'A002', 'C3'),
('A006', 0.11111111111111, 0.010416666666667, 'A002', 'C4'),
('A006', 0.11111111111111, 0.010416666666667, 'A002', 'C5'),
('A006', 0.11111111111111, 0.0056818181818181, 'A003', 'C1'),
('A006', 0.11111111111111, 0.0056818181818181, 'A003', 'C2'),
('A006', 0.11111111111111, 0.0056818181818181, 'A003', 'C3'),
('A006', 0.11111111111111, 0.0056818181818181, 'A003', 'C4'),
('A006', 0.11111111111111, 0.0056818181818181, 'A003', 'C5'),
('A006', 0.11111111111111, 0.00390625, 'A004', 'C1'),
('A006', 0.11111111111111, 0.00390625, 'A004', 'C2'),
('A006', 0.11111111111111, 0.00390625, 'A004', 'C3'),
('A006', 0.11111111111111, 0.00390625, 'A004', 'C4'),
('A006', 0.11111111111111, 0.00390625, 'A004', 'C5'),
('A006', 0.11111111111111, 0.0029761904761904, 'A005', 'C1'),
('A006', 0.11111111111111, 0.0029761904761904, 'A005', 'C2'),
('A006', 0.11111111111111, 0.0029761904761904, 'A005', 'C3'),
('A006', 0.11111111111111, 0.0029761904761904, 'A005', 'C4'),
('A006', 0.11111111111111, 0.0029761904761904, 'A005', 'C5'),
('A006', 1, 0.021634615384615, 'A006', 'C1'),
('A006', 1, 0.021634615384615, 'A006', 'C2'),
('A006', 1, 0.021634615384615, 'A006', 'C3'),
('A006', 1, 0.021634615384615, 'A006', 'C4'),
('A006', 1, 0.021634615384615, 'A006', 'C5'),
('A006', 9, 0.1633064516129, 'A007', 'C1'),
('A006', 9, 0.1633064516129, 'A007', 'C2'),
('A006', 9, 0.1633064516129, 'A007', 'C3'),
('A006', 9, 0.1633064516129, 'A007', 'C4'),
('A006', 9, 0.1633064516129, 'A007', 'C5'),
('A006', 9, 0.140625, 'A008', 'C1'),
('A006', 9, 0.140625, 'A008', 'C2'),
('A006', 9, 0.140625, 'A008', 'C3'),
('A006', 9, 0.140625, 'A008', 'C4'),
('A006', 9, 0.140625, 'A008', 'C5'),
('A007', 0.11111111111111, 0.0625, 'A001', 'C1'),
('A007', 0.11111111111111, 0.0625, 'A001', 'C2'),
('A007', 0.11111111111111, 0.0625, 'A001', 'C3'),
('A007', 0.11111111111111, 0.0625, 'A001', 'C4'),
('A007', 0.11111111111111, 0.0625, 'A001', 'C5'),
('A007', 0.11111111111111, 0.010416666666667, 'A002', 'C1'),
('A007', 0.11111111111111, 0.010416666666667, 'A002', 'C2'),
('A007', 0.11111111111111, 0.010416666666667, 'A002', 'C3'),
('A007', 0.11111111111111, 0.010416666666667, 'A002', 'C4'),
('A007', 0.11111111111111, 0.010416666666667, 'A002', 'C5'),
('A007', 0.11111111111111, 0.0056818181818181, 'A003', 'C1'),
('A007', 0.11111111111111, 0.0056818181818181, 'A003', 'C2'),
('A007', 0.11111111111111, 0.0056818181818181, 'A003', 'C3'),
('A007', 0.11111111111111, 0.0056818181818181, 'A003', 'C4'),
('A007', 0.11111111111111, 0.0056818181818181, 'A003', 'C5'),
('A007', 0.11111111111111, 0.00390625, 'A004', 'C1'),
('A007', 0.11111111111111, 0.00390625, 'A004', 'C2'),
('A007', 0.11111111111111, 0.00390625, 'A004', 'C3'),
('A007', 0.11111111111111, 0.00390625, 'A004', 'C4'),
('A007', 0.11111111111111, 0.00390625, 'A004', 'C5'),
('A007', 0.11111111111111, 0.0029761904761904, 'A005', 'C1'),
('A007', 0.11111111111111, 0.0029761904761904, 'A005', 'C2'),
('A007', 0.11111111111111, 0.0029761904761904, 'A005', 'C3'),
('A007', 0.11111111111111, 0.0029761904761904, 'A005', 'C4'),
('A007', 0.11111111111111, 0.0029761904761904, 'A005', 'C5'),
('A007', 0.11111111111111, 0.0024038461538461, 'A006', 'C1'),
('A007', 0.11111111111111, 0.0024038461538461, 'A006', 'C2'),
('A007', 0.11111111111111, 0.0024038461538461, 'A006', 'C3'),
('A007', 0.11111111111111, 0.0024038461538461, 'A006', 'C4'),
('A007', 0.11111111111111, 0.0024038461538461, 'A006', 'C5'),
('A007', 1, 0.018145161290323, 'A007', 'C1'),
('A007', 1, 0.018145161290323, 'A007', 'C2'),
('A007', 1, 0.018145161290323, 'A007', 'C3'),
('A007', 1, 0.018145161290323, 'A007', 'C4'),
('A007', 1, 0.018145161290323, 'A007', 'C5'),
('A007', 9, 0.140625, 'A008', 'C1'),
('A007', 9, 0.140625, 'A008', 'C2'),
('A007', 9, 0.140625, 'A008', 'C3'),
('A007', 9, 0.140625, 'A008', 'C4'),
('A007', 9, 0.140625, 'A008', 'C5'),
('A008', 0.11111111111111, 0.0625, 'A001', 'C1'),
('A008', 0.11111111111111, 0.0625, 'A001', 'C2'),
('A008', 0.11111111111111, 0.0625, 'A001', 'C3'),
('A008', 0.11111111111111, 0.0625, 'A001', 'C4'),
('A008', 0.11111111111111, 0.0625, 'A001', 'C5'),
('A008', 0.11111111111111, 0.010416666666667, 'A002', 'C1'),
('A008', 0.11111111111111, 0.010416666666667, 'A002', 'C2'),
('A008', 0.11111111111111, 0.010416666666667, 'A002', 'C3'),
('A008', 0.11111111111111, 0.010416666666667, 'A002', 'C4'),
('A008', 0.11111111111111, 0.010416666666667, 'A002', 'C5'),
('A008', 0.11111111111111, 0.0056818181818181, 'A003', 'C1'),
('A008', 0.11111111111111, 0.0056818181818181, 'A003', 'C2'),
('A008', 0.11111111111111, 0.0056818181818181, 'A003', 'C3'),
('A008', 0.11111111111111, 0.0056818181818181, 'A003', 'C4'),
('A008', 0.11111111111111, 0.0056818181818181, 'A003', 'C5'),
('A008', 0.11111111111111, 0.00390625, 'A004', 'C1'),
('A008', 0.11111111111111, 0.00390625, 'A004', 'C2'),
('A008', 0.11111111111111, 0.00390625, 'A004', 'C3'),
('A008', 0.11111111111111, 0.00390625, 'A004', 'C4'),
('A008', 0.11111111111111, 0.00390625, 'A004', 'C5'),
('A008', 0.11111111111111, 0.0029761904761904, 'A005', 'C1'),
('A008', 0.11111111111111, 0.0029761904761904, 'A005', 'C2'),
('A008', 0.11111111111111, 0.0029761904761904, 'A005', 'C3'),
('A008', 0.11111111111111, 0.0029761904761904, 'A005', 'C4'),
('A008', 0.11111111111111, 0.0029761904761904, 'A005', 'C5'),
('A008', 0.11111111111111, 0.0024038461538461, 'A006', 'C1'),
('A008', 0.11111111111111, 0.0024038461538461, 'A006', 'C2'),
('A008', 0.11111111111111, 0.0024038461538461, 'A006', 'C3'),
('A008', 0.11111111111111, 0.0024038461538461, 'A006', 'C4'),
('A008', 0.11111111111111, 0.0024038461538461, 'A006', 'C5'),
('A008', 0.11111111111111, 0.002016129032258, 'A007', 'C1'),
('A008', 0.11111111111111, 0.002016129032258, 'A007', 'C2'),
('A008', 0.11111111111111, 0.002016129032258, 'A007', 'C3'),
('A008', 0.11111111111111, 0.002016129032258, 'A007', 'C4'),
('A008', 0.11111111111111, 0.002016129032258, 'A007', 'C5'),
('A008', 1, 0.015625, 'A008', 'C1'),
('A008', 1, 0.015625, 'A008', 'C2'),
('A008', 1, 0.015625, 'A008', 'C3'),
('A008', 1, 0.015625, 'A008', 'C4'),
('A008', 1, 0.015625, 'A008', 'C5');

-- --------------------------------------------------------

--
-- Table structure for table `analisa_kriteria`
--

CREATE TABLE `analisa_kriteria` (
  `kriteria_pertama` varchar(2) NOT NULL,
  `nilai_analisa_kriteria` double NOT NULL,
  `hasil_analisa_kriteria` double NOT NULL,
  `kriteria_kedua` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `analisa_kriteria`
--

INSERT INTO `analisa_kriteria` (`kriteria_pertama`, `nilai_analisa_kriteria`, `hasil_analisa_kriteria`, `kriteria_kedua`) VALUES
('C1', 1, 0.69230769230769, 'C1'),
('C1', 9, 0.86449399656947, 'C2'),
('C1', 9, 0.49001814882033, 'C3'),
('C1', 9, 0.38297872340426, 'C4'),
('C1', 9, 0.375, 'C5'),
('C2', 0.11111111111111, 0.076923076923076, 'C1'),
('C2', 1, 0.096054888507719, 'C2'),
('C2', 8, 0.43557168784029, 'C3'),
('C2', 7, 0.29787234042553, 'C4'),
('C2', 7, 0.29166666666667, 'C5'),
('C3', 0.11111111111111, 0.076923076923076, 'C1'),
('C3', 0.125, 0.012006861063465, 'C2'),
('C3', 1, 0.054446460980036, 'C3'),
('C3', 6, 0.25531914893617, 'C4'),
('C3', 5, 0.20833333333333, 'C5'),
('C4', 0.11111111111111, 0.076923076923076, 'C1'),
('C4', 0.14285714285714, 0.013722126929674, 'C2'),
('C4', 0.16666666666667, 0.0090744101633396, 'C3'),
('C4', 1, 0.042553191489362, 'C4'),
('C4', 2, 0.083333333333333, 'C5'),
('C5', 0.11111111111111, 0.076923076923076, 'C1'),
('C5', 0.14285714285714, 0.013722126929674, 'C2'),
('C5', 0.2, 0.010889292196007, 'C3'),
('C5', 0.5, 0.021276595744681, 'C4'),
('C5', 1, 0.041666666666667, 'C5');

-- --------------------------------------------------------

--
-- Table structure for table `data_alternatif`
--

CREATE TABLE `data_alternatif` (
  `id_alternatif` varchar(4) NOT NULL,
  `nik` char(18) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `tempat_lahir` varchar(100) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `kelamin` enum('pria','wanita') NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `jabatan` varchar(20) NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `pendidikan` varchar(20) NOT NULL,
  `hasil_akhir` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_alternatif`
--

INSERT INTO `data_alternatif` (`id_alternatif`, `nik`, `nama`, `tempat_lahir`, `tanggal_lahir`, `kelamin`, `alamat`, `jabatan`, `tanggal_masuk`, `pendidikan`, `hasil_akhir`) VALUES
('A001', '001', 'Siti Maemunah', 'Bekasi', '1980-06-04', 'wanita', 'Jl.Benda Barat 10A No.13-14 Pamulang Permai 2-Ciputat', 'Leader', '2018-06-01', 'SMA', 0.41841312725220003),
('A002', '002', 'Rian Kriswandi', 'Bekasi', '1989-05-18', 'pria', 'Jl.Padat Karya RT01/06 Kampung Pedurenan No.118, Kel.Duren Jaya, Kec.Bekasi TImur', 'Leader', '2020-01-15', 'SMA', 0.22249648519025952),
('A003', '003', 'Herdi Herdiana', 'Ciamis', '1988-07-05', 'pria', 'Jl.Sersan Idris No.6 RT006 RW006,Kel.Marga Jaya,Kec.Bekasi Selatan', 'CSO', '2018-06-01', 'SMA', 0.1480896540704405),
('A004', '004', 'Titin Suhartini', 'Bekasi', '1979-09-30', 'wanita', 'Jl.Pramuka No.37 RT04 RW02,Kel.Marga Jaya,Kec.Bekasi Barat', 'CSO', '2018-05-01', 'SMA', 0.0988782324315856),
('A005', '005', 'Rini Andrias', 'Bekasi', '2000-04-06', 'wanita', 'Jl.Kampung Kandang Gede RT002 RW008 Kel.Harapan Mulya, Kec.Bekasi Timur', 'CSO', '2018-05-01', 'SMA', 0.0619456073729463),
('A006', '006', 'Nurfadilla', 'Bekasi', '2000-06-25', 'wanita', 'Jl.Mawar Raya RT05 RW02 Kel.Margahayu Kec.Bekasi Timur', 'CSO', '2020-01-20', 'SMA', 0.0323551888120547),
('A007', '007', 'Andhika', 'Bekasi', '2001-06-16', 'pria', 'Kp.Penggilingan Tengah, Desa Kebalen, Kabupaten Bekasi, RT004 RW004 Bekasi Utara', 'CSO', '2020-01-24', 'SMA', 0.030831866596106),
('A008', '008', 'Ahmad Fauzi', 'Bekasi', '2002-05-15', 'pria', 'Perjuangan Teluk Pucung RT01 RW01', 'CSO', '2020-12-13', 'SMA', 0.0131907375638474),
('A009', '009', 'Hairul Anwar', 'Bekasi', '2000-10-23', 'pria', 'Jl.Perjuangan Teluk Pucung RT03 RW 01', 'CSO', '2020-01-04', 'SMA', NULL),
('A010', '010', 'SIti Aisyah', 'Bekasi', '1988-03-28', 'wanita', 'Jl.Ujung Harapan Gg.Assalam 3 RT002 RW015', 'CSO', '2020-07-01', 'SMA', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data_kriteria`
--

CREATE TABLE `data_kriteria` (
  `id_kriteria` varchar(2) NOT NULL,
  `nama_kriteria` varchar(45) NOT NULL,
  `jumlah_kriteria` double NOT NULL,
  `bobot_kriteria` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_kriteria`
--

INSERT INTO `data_kriteria` (`id_kriteria`, `nama_kriteria`, `jumlah_kriteria`, `bobot_kriteria`) VALUES
('C1', 'Loyalitas', 1.4444444444444402, 0.56095971222035),
('C2', 'Kedisiplinan', 10.410714285714281, 0.239617732072657),
('C3', 'Keterampilan', 18.36666666666667, 0.12140577624721541),
('C4', 'Kerapihan', 23.5, 0.04512122776775692),
('C5', 'Kerjasama', 24, 0.032895551692021);

-- --------------------------------------------------------

--
-- Table structure for table `jum_alt_kri`
--

CREATE TABLE `jum_alt_kri` (
  `id_alternatif` varchar(4) NOT NULL,
  `id_kriteria` varchar(2) NOT NULL,
  `jumlah_alt_kri` double NOT NULL,
  `skor_alt_kri` double NOT NULL,
  `hasil_alt_kri` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jum_alt_kri`
--

INSERT INTO `jum_alt_kri` (`id_alternatif`, `id_kriteria`, `jumlah_alt_kri`, `skor_alt_kri`, `hasil_alt_kri`) VALUES
('A001', 'C1', 1.7777777777777704, 0.43222384737593916, 0.24246016503878),
('A001', 'C2', 1.7777777777777704, 0.41254764010996964, 0.098853729895078),
('A001', 'C3', 1.7777777777777704, 0.3950576780957744, 0.04796228407164),
('A001', 'C4', 1.7777777777777704, 0.3794087647146524, 0.017119389289773),
('A001', 'C5', 1.7777777777777704, 0.3653247426716426, 0.012017558956929),
('A002', 'C1', 10.666666666666664, 0.22598809509630388, 0.12677021679045),
('A002', 'C2', 10.666666666666664, 0.22101357967728583, 0.052958772719531),
('A002', 'C3', 10.666666666666664, 0.21659178819371422, 0.02629549417443),
('A002', 'C4', 10.666666666666664, 0.2126354484452554, 0.0095943725007975),
('A002', 'C5', 10.666666666666664, 0.20907474267164253, 0.006877629005051),
('A003', 'C1', 19.555555555555554, 0.1482374017171713, 0.083155210207557),
('A003', 'C2', 19.555555555555554, 0.1480269048499482, 0.03546987122588),
('A003', 'C3', 19.555555555555554, 0.14783979652352763, 0.017948605257169),
('A003', 'C4', 19.555555555555554, 0.1476723838104145, 0.0066631592649173),
('A003', 'C5', 19.555555555555554, 0.1475217123686127, 0.0048528081149172),
('A004', 'C1', 28.444444444444443, 0.0968476873687929, 0.054327650835604),
('A004', 'C2', 28.444444444444443, 0.0997406158446757, 0.023899620164231),
('A004', 'C3', 28.444444444444443, 0.10231210782323817, 0.012421280869769),
('A004', 'C4', 28.444444444444443, 0.10461291643563618, 0.0047202632299417),
('A004', 'C5', 28.444444444444443, 0.1066836441867944, 0.0035094173320399),
('A005', 'C1', 37.33333333333332, 0.05829158063891737, 0.032699228300076),
('A005', 'C2', 37.33333333333332, 0.06349749218661221, 0.015215125070057),
('A005', 'C3', 37.33333333333332, 0.06812496911789655, 0.0082707647575758),
('A005', 'C4', 37.33333333333332, 0.07226534321430882, 0.003260701010888),
('A005', 'C5', 37.33333333333332, 0.07599167990107988, 0.0024997882343495),
('A006', 'C1', 46.222222222222214, 0.027405736762885855, 0.015373514207695),
('A006', 'C2', 46.222222222222214, 0.034457247726823494, 0.0082565675537672),
('A006', 'C3', 46.222222222222214, 0.04072525747254583, 0.0049442814963221),
('A006', 'C4', 46.222222222222214, 0.04633347671871845, 0.0020906233562974),
('A006', 'C5', 46.222222222222214, 0.051380874040273805, 0.001690202197973),
('A007', 'C1', 55.11111111111111, 0.030831866596105574, 0.017295435012968),
('A007', 'C2', 55.11111111111111, 0.030831866596105574, 0.0073878619493255),
('A007', 'C3', 55.11111111111111, 0.030831866596105578, 0.0037431666972508),
('A007', 'C4', 55.11111111111111, 0.03083186659610558, 0.001391171675188),
('A007', 'C5', 55.11111111111111, 0.030831866596105578, 0.0010142312613737),
('A008', 'C1', 64, 0.013190737563847449, 0.00739947234779),
('A008', 'C2', 64, 0.013190737563847449, 0.0031607346194147),
('A008', 'C3', 64, 0.013190737563847449, 0.0016014317332122),
('A008', 'C4', 64, 0.013190737563847456, 0.00059518227404307),
('A008', 'C5', 64, 0.013190737563847454, 0.00043391658938743);

-- --------------------------------------------------------

--
-- Table structure for table `nilai`
--

CREATE TABLE `nilai` (
  `id_nilai` int(11) NOT NULL,
  `jum_nilai` double NOT NULL,
  `ket_nilai` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai`
--

INSERT INTO `nilai` (`id_nilai`, `jum_nilai`, `ket_nilai`) VALUES
(2, 9, 'Mutlak sangat penting dari'),
(3, 8, 'Mendekati mutlak dari'),
(8, 7, 'Sangat penting dari'),
(9, 6, 'Mendekati sangat penting dari'),
(10, 5, 'Lebih penting dari'),
(11, 4, 'Mendekati lebih penting dari'),
(12, 3, 'Sedikit lebih penting dari'),
(13, 2, 'Mendekati sedikit lebih penting dari'),
(14, 1, 'Sama penting dengan'),
(15, 0.5, '1 bagi mendekati sedikit lebih penting dari'),
(16, 0.333, '1 bagi sedikit lebih penting dari'),
(17, 0.25, '1 bagi mendekati lebih penting dari'),
(18, 0.2, '1 bagi lebih penting dari'),
(19, 0.167, '1 bagi mendekati sangat penting dari'),
(20, 0.143, '1 bagi sangat penting dari'),
(21, 0.125, '1 bagi mendekati mutlak dari'),
(22, 0.1, '1 bagi mutlak sangat penting dari');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_awal`
--

CREATE TABLE `nilai_awal` (
  `id_nilai_awal` int(11) NOT NULL,
  `id_alternatif` varchar(4) NOT NULL,
  `nilai` varchar(5) NOT NULL,
  `keterangan` enum('B','C','K') NOT NULL,
  `periode` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai_awal`
--

INSERT INTO `nilai_awal` (`id_nilai_awal`, `id_alternatif`, `nilai`, `keterangan`, `periode`) VALUES
(43, 'A001', '74.4', 'B', '2020'),
(44, 'A002', '73', 'B', '2020'),
(45, 'A003', '70.2', 'B', '2020'),
(46, 'A004', '57.2', 'B', '2020'),
(47, 'A005', '67.4', 'B', '2020'),
(52, 'A006', '74.6', 'B', '2020'),
(53, 'A007', '70', 'B', '2021'),
(54, 'A008', '50', 'B', '2021');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_awal_detail`
--

CREATE TABLE `nilai_awal_detail` (
  `id_nilai_awal_detail` int(11) NOT NULL,
  `id_nilai_awal` int(11) NOT NULL,
  `id_kriteria` varchar(2) NOT NULL,
  `nilai` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai_awal_detail`
--

INSERT INTO `nilai_awal_detail` (`id_nilai_awal_detail`, `id_nilai_awal`, `id_kriteria`, `nilai`) VALUES
(212, 43, 'C1', 70),
(213, 43, 'C2', 66),
(214, 43, 'C3', 76),
(215, 43, 'C4', 90),
(216, 43, 'C5', 70),
(217, 44, 'C1', 90),
(218, 44, 'C2', 66),
(219, 44, 'C3', 76),
(220, 44, 'C4', 88),
(221, 44, 'C5', 45),
(222, 45, 'C1', 60),
(223, 45, 'C2', 70),
(224, 45, 'C3', 88),
(225, 45, 'C4', 88),
(226, 45, 'C5', 45),
(227, 46, 'C1', 40),
(228, 46, 'C2', 66),
(229, 46, 'C3', 60),
(230, 46, 'C4', 50),
(231, 46, 'C5', 70),
(232, 47, 'C1', 50),
(233, 47, 'C2', 77),
(234, 47, 'C3', 80),
(235, 47, 'C4', 60),
(236, 47, 'C5', 70),
(252, 52, 'C1', 60),
(253, 52, 'C2', 87),
(254, 52, 'C3', 70),
(255, 52, 'C4', 76),
(256, 52, 'C5', 80),
(257, 53, 'C1', 90),
(258, 53, 'C2', 70),
(259, 53, 'C3', 60),
(260, 53, 'C4', 50),
(261, 53, 'C5', 80),
(262, 54, 'C1', 60),
(263, 54, 'C2', 50),
(264, 54, 'C3', 40),
(265, 54, 'C4', 60),
(266, 54, 'C5', 40);

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `role` enum('atasan','kepegawaian','manajer','karyawan') NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_lengkap`, `role`, `username`, `password`) VALUES
(0, 'Karyawan', 'karyawan', 'karyawan', '9e014682c94e0f2cc834bf7348bda428'),
(1, 'HRD', 'kepegawaian', 'hrd', '4bf31e6f4b818056eaacb83dff01c9b8'),
(2, 'Supervisor', 'atasan', 'supervisor', '09348c20a019be0318387c08df7a783d'),
(3, 'Manajer Area', 'manajer', 'manajerarea', 'ed0514c9acae234521b44cd6453bdcc7');

-- --------------------------------------------------------

--
-- Table structure for table `ranking`
--

CREATE TABLE `ranking` (
  `kriteria` varchar(2) NOT NULL,
  `skor_bobot` double NOT NULL,
  `alternatif` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `analisa_alternatif`
--
ALTER TABLE `analisa_alternatif`
  ADD PRIMARY KEY (`alternatif_pertama`,`alternatif_kedua`,`id_kriteria`),
  ADD KEY `alternatif_kedua` (`alternatif_kedua`),
  ADD KEY `id_kriteria` (`id_kriteria`);

--
-- Indexes for table `analisa_kriteria`
--
ALTER TABLE `analisa_kriteria`
  ADD PRIMARY KEY (`kriteria_pertama`,`kriteria_kedua`),
  ADD KEY `kriteria_kedua` (`kriteria_kedua`);

--
-- Indexes for table `data_alternatif`
--
ALTER TABLE `data_alternatif`
  ADD PRIMARY KEY (`id_alternatif`);

--
-- Indexes for table `data_kriteria`
--
ALTER TABLE `data_kriteria`
  ADD PRIMARY KEY (`id_kriteria`);

--
-- Indexes for table `jum_alt_kri`
--
ALTER TABLE `jum_alt_kri`
  ADD PRIMARY KEY (`id_alternatif`,`id_kriteria`),
  ADD KEY `id_kriteria` (`id_kriteria`);

--
-- Indexes for table `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `nilai_awal`
--
ALTER TABLE `nilai_awal`
  ADD PRIMARY KEY (`id_nilai_awal`,`id_alternatif`),
  ADD KEY `alternatif` (`id_alternatif`);

--
-- Indexes for table `nilai_awal_detail`
--
ALTER TABLE `nilai_awal_detail`
  ADD PRIMARY KEY (`id_nilai_awal_detail`,`id_nilai_awal`),
  ADD KEY `alternatif` (`id_nilai_awal`),
  ADD KEY `id_kriteria` (`id_kriteria`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `ranking`
--
ALTER TABLE `ranking`
  ADD PRIMARY KEY (`kriteria`,`alternatif`),
  ADD KEY `alternatif` (`alternatif`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id_nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `nilai_awal`
--
ALTER TABLE `nilai_awal`
  MODIFY `id_nilai_awal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `nilai_awal_detail`
--
ALTER TABLE `nilai_awal_detail`
  MODIFY `id_nilai_awal_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=267;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `analisa_alternatif`
--
ALTER TABLE `analisa_alternatif`
  ADD CONSTRAINT `analisa_alternatif_ibfk_1` FOREIGN KEY (`id_kriteria`) REFERENCES `data_kriteria` (`id_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `analisa_alternatif_ibfk_2` FOREIGN KEY (`alternatif_pertama`) REFERENCES `data_alternatif` (`id_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `analisa_alternatif_ibfk_3` FOREIGN KEY (`alternatif_kedua`) REFERENCES `data_alternatif` (`id_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `analisa_kriteria`
--
ALTER TABLE `analisa_kriteria`
  ADD CONSTRAINT `analisa_kriteria_ibfk_1` FOREIGN KEY (`kriteria_pertama`) REFERENCES `data_kriteria` (`id_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `analisa_kriteria_ibfk_2` FOREIGN KEY (`kriteria_kedua`) REFERENCES `data_kriteria` (`id_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jum_alt_kri`
--
ALTER TABLE `jum_alt_kri`
  ADD CONSTRAINT `jum_alt_kri_ibfk_1` FOREIGN KEY (`id_kriteria`) REFERENCES `data_kriteria` (`id_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `jum_alt_kri_ibfk_2` FOREIGN KEY (`id_alternatif`) REFERENCES `data_alternatif` (`id_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nilai_awal`
--
ALTER TABLE `nilai_awal`
  ADD CONSTRAINT `nilai_awal_ibfk_1` FOREIGN KEY (`id_alternatif`) REFERENCES `data_alternatif` (`id_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nilai_awal_detail`
--
ALTER TABLE `nilai_awal_detail`
  ADD CONSTRAINT `nilai_awal_detail_ibfk_1` FOREIGN KEY (`id_kriteria`) REFERENCES `data_kriteria` (`id_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nilai_awal_detail_ibfk_2` FOREIGN KEY (`id_nilai_awal`) REFERENCES `nilai_awal` (`id_nilai_awal`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ranking`
--
ALTER TABLE `ranking`
  ADD CONSTRAINT `ranking_ibfk_1` FOREIGN KEY (`kriteria`) REFERENCES `data_kriteria` (`id_kriteria`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ranking_ibfk_2` FOREIGN KEY (`alternatif`) REFERENCES `data_alternatif` (`id_alternatif`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
